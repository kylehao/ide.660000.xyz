window.APP_CONFIG = {
  'headImage': 'https://p6-tt.byteimg.com/origin/pgc-image/409f71055789411493a6a9cac0cec025.jpg',
  'headColor': '#d09ec1'
}