# poi-theme
poi-theme 基于 [ShareList](https://github.com/reruin/sharelist) 默认主题开发

## 预览
![](https://i.loli.net/2021/04/21/hwm5S3J9vt6yU4A.png)
![](https://i.loli.net/2021/04/21/hXqtV54cz2MZQT6.png)
![](https://i.loli.net/2021/04/21/r4myT5SAse6QPO8.png)

## 功能
- 添加头图支持
- 列表添加预览/回退
- 调整展示样式

## 使用
1. 将本项目放入sharelist\theme目录
2. 修改本项目\script\config.js中头图与预览页背景色设置
3. 在sharelist后台选择poi-theme主题
4. 坐与放宽(

## 许可
[Apache-2](http://www.apache.org/licenses/LICENSE-2.0)   
Copyright (c) 2018-present, Reruin
