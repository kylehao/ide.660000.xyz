# Baidu


将```挂载路径留空```，ShareList将自动开启挂载向导，按指示操作即可。

?> 免责申明： 此插件基于[网盘开放平台](https://pan.baidu.com/union/home) 实现，[点击查看文档](https://pan.baidu.com/union/document/basic)，使用时请遵守[使用协议](https://pan.baidu.com/union/document/protocol)。  

?> 由于大文件(估测50M)无法直连下载，sharelist将强制中转。

?> 大文件的实际下载速度可能受多方面因素影响。   