A react template built with :
- [vite](https://cn.vitejs.dev/)
- [chakra-ui](https://chakra-ui.com/)
- [react-router](https://reactrouter.com/web/)
- [react-icons](https://react-icons.github.io/react-icons/)